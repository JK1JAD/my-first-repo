# GitHub Pages スターター

このリポジトリは GitHub Pages 公開確認用の最小構成です。

## 使い方
1. このリポジトリに `index.html`（本ファイル）を置きます（ルート直下）。
2. GitHub の **Settings → Pages** を開き、以下を設定して **Save**：
   - Source: **Deploy from a branch**
   - Branch: **main**, Folder: **/** (root)
3. 数十秒待つと、緑色のボックスに公開URLが表示されます。

## トラブルシュート
- ページが出ない: `index.html` がルート直下にあるか確認 / 保存後1〜2分待ってみる / リロード。
